#!/bin/bash
set -e

echo "Installing Atelier Capacitor dependencies..."
npm install

if [ ! -d ios ]; then
  npx cap add ios
fi

npx cap sync ios
npx cap open ios
