# Atelier — Capacitor iOS

This project wraps the existing Atelier Netlify web app as an iOS application using Capacitor.

## Requirements

- macOS
- Xcode
- Node.js 20+
- CocoaPods (normally installed/managed with Xcode tooling)
- Apple Developer account for device/App Store signing

## 1. Install dependencies

```bash
npm install
```

## 2. Add the iOS platform

```bash
npx cap add ios
```

## 3. Sync

```bash
npx cap sync ios
```

## 4. Open in Xcode

```bash
npx cap open ios
```

In Xcode:
1. Select the `App` target.
2. Set the Team under Signing & Capabilities.
3. Keep Bundle Identifier as `com.atelier.wardrobe` (or change it).
4. Select an iPhone simulator/device.
5. Run.

## 5. Create an IPA

For App Store/TestFlight:
- In Xcode choose Product → Archive.
- In Organizer choose Distribute App.
- Select App Store Connect or Ad Hoc as appropriate.
- Complete Apple's signing/distribution steps.

## Important

The current configuration loads the live Netlify Atelier site:
https://enchanting-pithivier-14be52.netlify.app

This is intentional so you can turn the existing site into an iOS shell without rebuilding the web UI.

For a production App Store release, the recommended next step is to bundle the actual Atelier web build inside the app (`webDir`) rather than depending on a live external URL. That also makes offline behavior and release stability much better.

## Native features

Once the basic app is running, Capacitor plugins can be added for:
- Camera/photo picker for wardrobe photos
- Local notifications for laundry reminders
- Filesystem/storage
- Haptics

The current website already exposes an Upload photo flow, so native photo integration is a natural next enhancement.
